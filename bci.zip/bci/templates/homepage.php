<section class="padding-top-40 padding-bottom-40">
    <div class="group">
		<?php dynamic_sidebar('Home'); ?>
    </div>
</section>