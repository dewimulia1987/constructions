	</div><!-- end #content -->
</main><!-- end main -->

<footer id="footer" role="contentinfo">
	<div id="footer-bottom" class="font-size-12 aligncenter back-first color-black">
		<div class="group hasfloat">
			<div class="row py-2">
				<div class="copyright d-flex flex-wrap col">
					<span class="copyright">&copy; Copyright <?php echo date('Y'); ?> <?php bloginfo('name'); ?></span>
					<span> | </span>
					<span class="creator">Website by <a class="color-black color-second-hover" href="https://degivi.id/dewimulia" title="Degivi" target="_blank">Dewi Mulia</a></span>
				</div> 
			</div>
		</div>
	</div>
</footer>
</div><!-- end #page -->
<?php wp_footer(); ?>
</body>
</html>